﻿using System;

namespace AverageProgram
{
    class Program
    {
        static void Main(string[] args)
        {
            double num1, num2, num3, num4;
            Console.Write("Enter the First Number: ");
            num1 = Convert.ToDouble(Console.ReadLine());
            Console.Write("Enter he Second Number: ");
            num2 = Convert.ToDouble(Console.ReadLine());
            Console.Write("Enter the Third Number: ");
            num3 = Convert.ToDouble(Console.ReadLine());
            Console.Write("Enter the Fourth Number: ");
            num4 = Convert.ToDouble(Console.ReadLine());

            double result = (num1 + num2 + num3 + num4)/4;
            Console.WriteLine("The average of{0},{1},{2},{3} numbers are :", num1,num2,num3, result);
             

        }
    }
}
