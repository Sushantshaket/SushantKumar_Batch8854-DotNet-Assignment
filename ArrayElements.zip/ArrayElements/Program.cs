﻿using System;

namespace ArrayElements
{
    public class ArrayProgram1
    {
        static void Main(string[] args)
        {
            int[] arr = new int[11];
            int i;
            Console.Write("\n\n Read and Print elements of an array:\n");
            Console.Write("--------:\n");
            Console.Write("Input 11 elements of an array:\n");
            for(i=0; i < 11; i++)
            {
                Console.Write("element - {0}:", i);
                arr[i] = Convert.ToInt32(Console.ReadLine());
            }
            Console.Write("\nElements in array are: ");
            for(i=0; i<11; i++)
            {
                Console.Write("{0} ", arr[i]);
            }
            Console.Write("\n");
        }
    }
}
