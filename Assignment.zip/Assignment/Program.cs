﻿using System;

namespace Assignment
{
    class AgeValidation
    {
        static void Main(string[] args)
        {
            int age;
            Console.Write("Check the age of voter for casting the vote: \n");
            Console.Write("Enter the age: \n");
            age = Convert.ToInt32(Console.ReadLine());
            if (age < 18)
            {
                Console.WriteLine("You are not eligible");

            }
            else
                Console.WriteLine("You are eligible");
            
        }
    }
}
